!function(d,s,id){var js,fjs=d.getElementsByTagName(s)[0];if(!d.getElementById(id)){js=d.createElement(s);js.id=id;js.src='https://weatherwidget.io/js/widget.min.js';fjs.parentNode.insertBefore(js,fjs);}}(document,'script','weatherwidget-io-js');

const aboutUs = document.getElementById('aboutUs');
const tour = document.getElementById('tour');
const greekNights1  = document.getElementById('greekNights1');
const greekNights  = document.getElementById('greekNights');
const checkIn = document.getElementById('checkIn');

const contentAboutUs  = document.getElementById('aboutUs-content')
const contentTour  = document.getElementById('tour-content')
const contentGreekNights = document.getElementById('greekNights-content')
const contentGreekNights1 = document.getElementById('greekNights-content1')
const contentCheckIn  = document.getElementById('checkIn-content')


const content = document.getElementById('content');

function clean(e) {
    e.className = "";
}

function cleanVisibility() {
    document.getElementById("aboutUs-content").style.display = "none";
    document.getElementById("tour-content").style.display = "none";
  
    document.getElementById("greekNights-content").style.display = "none";
    document.getElementById("checkIn-content").style.display = "none";

}

aboutUs.addEventListener('click', function(e) {
    //console.log("About us 1")
    const classList = e.target.classList;
    //console.log(classList)
    clean(e);
    e.target.classList.add('aboutUs-content')
    console.log(e.target.classList)


    cleanVisibility();

    document.getElementById("aboutUs-content").style.display = "inline-block";
    document.getElementById("aboutUs-content").style.visibility = "visible";

});

tour.addEventListener('click', function(e) {

    cleanVisibility();
    document.getElementById("tour-content").style.display = "inline-block";
    document.getElementById("tour-content").style.visibility = "visible";


});

greekNights.addEventListener('click', function() {
    cleanVisibility();

    document.getElementById("greekNights-content").style.display = "inline-block";
    document.getElementById("greekNights-content").style.visibility = "visible";
    // var iframe = document.createElement('iframe');
    // iframe.id = 'iframe';
    // iframe.style.display = 'none';
    // document.body.appendChild(iframe);
    // if(this.href='tema.html')
    // { iframe.src = 'mytext.txt';
    // var text = document.getElementById('iframe').contentDocument.body.firstChild.innerHTML;
    // //contentGreekNights.innerText=text;
   
   
        
    
    // contentGreekNights.innerText=text;}

  
    
    
    
    
});
// greekNights1.addEventListener('click', function() {
//     cleanVisibility();

//     document.getElementById("greekNights-content1").style.display = "inline-block";
//     document.getElementById("greekNights-content1").style.visibility = "visible";
//     var iframe = document.createElement('iframe');
//     iframe.id = 'iframe';
//     iframe.style.display = 'none';
//     document.body.appendChild(iframe);
//     iframe.src = 'mytext1.txt';
//     setTimeout(function(){
//         var text = document.getElementById('iframe').contentDocument.body.firstChild.innerHTML;
//         contentGreekNights1.innerText=text;
//     }, 20);
    
    
    
    
// });

checkIn.addEventListener('click', function() {
    cleanVisibility();

    document.getElementById("checkIn-content").style.display = "inline-block";
    document.getElementById("checkIn-content").style.visibility = "visible";
});


let saveFile = () => {
    	
    // Get the data from each element on the form.
    const firstName = document.getElementById('fname');
    const lastName = document.getElementById('lname');
    const roomType = document.getElementById('roomType');
    const checkInToFile = document.getElementById('checkInToFile');
    const checkOut = document.getElementById('checkOut');
    
    // This variable stores all the data.
    let data = 
        '\r First name: ' + firstName.value + ' \r\n ' + 
        'Last Name: ' + lastName.value + ' \r\n ' + 
        'Room Type: ' + roomType.value + ' \r\n ' + 
        'Check in: ' + checkInToFile.value + ' \r\n ' + 
        'Date of Birth: ' + birthDay.value + ' \r\n ' + 
        'Check out: ' + checkOut.value;
        
    
    // Convert the text to BLOB.
    const textToBLOB = new Blob([data], { type: 'text/plain' });
    const sFileName = 'formData.txt';	   // The file to save the data.

    let newLink = document.createElement("a");
    newLink.download = sFileName;

    if (window.webkitURL != null) {
        newLink.href = window.webkitURL.createObjectURL(textToBLOB);
    }
    else {
        newLink.href = window.URL.createObjectURL(textToBLOB);
        newLink.style.display = "none";
        document.body.appendChild(newLink);
    }

    newLink.click(); 
}

// window.history.pushState('', 'New Page Title', '/hellashotel.com');