"use strict";
//tabel cu datele si colorarea celulelor in functie de distanta valorii fata de medie
const btnAn = document.getElementById("btnAn");//butonul la apasarea caruia desenez tabelul
// s-a apasat pe buton
btnAn.addEventListener("click", function () {
    document.getElementById("tabel").style.display = "table";
    //daca tabelul are deja elemente in el acestea sunt sterse-pentru ca atunci cand se schimba anul, sa se rescrie tabelul nu sa se construiasca altul nou separat-sa fie un singur tabel
    const parinte = document.getElementById("tableBody");
    while (parinte.hasChildNodes()) {
        parinte.removeChild(parinte.firstChild);
    }
    //citirea din json
    fetch("./media/eurostat.json")
        .then(response => response.json())
        .then((date) => {
            let mediaPIB = 0;
            let maxPIB = 0;
            let minPIB = 0;

            let mediaSV = 0;
            let maxSV = 0;
            let minSV = 0;

            let mediaPOP = 0;
            let maxPOP = 0;
            let minPOP = 0;

            let nr_pib_nenul = 0;
            let nr_sv_nenul = 0;
            let nr_pop_nenul = 0;

            let nr_tari_distincte = 0;
            const vector = date;

            //salvarea intr-un vector a tuturor tarilor
            const tari = [];
            for (let i = 0; i < vector.length; i++) {

                tari.push(vector[i].tara)

            }
            //console.log(tari);
            //construire vector cu tari distincte
            const tari_distincte = []
            for (let i = 0; i < tari.length; i++) {
                if (nr_tari_distincte === 0) {
                    tari_distincte.push(tari[i]);
                    nr_tari_distincte++;
                }
                else {
                    let ok = 1;
                    for (let j = 0; j < nr_tari_distincte; j++) {
                        if (tari_distincte[j] === tari[i]) {
                            ok = 0;
                        }
                    }
                    if (ok === 1) {
                        tari_distincte.push(tari[i]);
                        nr_tari_distincte++;
                    }
                }

            }
            //console.log(tari_distincte);
            //verific ce an a fost ales de utlizator
            const anAles = document.getElementById("anAles");
            const an = anAles.options[anAles.selectedIndex].innerHTML;


            //console.log(an);
            //pentru fiecare tara distincta construiesc un obiect de tip data cu nume tara, pib,sv si pop pe care il populez cu valorile corespunzatoare anului respectiv
            for (let j = 0; j < tari_distincte.length; j++) {
                //console.log(tari_distincte[j]);
                const data = {
                    tara: tari_distincte[j],
                    pib: "-",
                    sv: "-",
                    pop: "-"

                };
                for (let i = 0; i < vector.length; i++) {
                    //pentru fiecare valoare verific si daca este nula sau nu, in caz negativ o adun la suma pentru medie si o contorizez
                    if (vector[i].an === an && vector[i].tara === tari_distincte[j]) {
                        if (vector[i].indicator === 'PIB') {
                            data.pib = vector[i].valoare;
                            //console.log(parseFloat(vector[i].valoare));
                            if (vector[i].valoare != null) {
                                mediaPIB += parseFloat(vector[i].valoare);
                                nr_pib_nenul++;
                            }


                            //console.log(mediaPIB)

                        }
                        if (vector[i].indicator === 'SV') {
                            data.sv = vector[i].valoare;
                            if (vector[i].valoare != null) {
                                mediaSV += parseFloat(vector[i].valoare);
                                nr_sv_nenul++;
                            }

                        }
                        if (vector[i].indicator === 'POP') {
                            data.pop = vector[i].valoare;
                            if (vector[i].valoare != null) {
                                mediaPOP += parseInt(vector[i].valoare);
                                nr_pop_nenul++;
                            }

                        }

                    }

                }

                //populez tabelul
                //console.log(data);
                var tRow = document.createElement("tr");

                var cTara = document.createElement("td");
                cTara.innerHTML = data.tara
                tRow.appendChild(cTara);

                var cPIB = document.createElement("td");
                cPIB.innerHTML = data.pib
                tRow.appendChild(cPIB);

                var cSV = document.createElement("td");
                cSV.innerHTML = data.sv
                tRow.appendChild(cSV);

                var cPOP = document.createElement("td");
                cPOP.innerHTML = data.pop
                tRow.appendChild(cPOP);

                var tBody = document.getElementById("tableBody");
                tBody.appendChild(tRow);
            }
            //calculez mediile
            mediaPIB = mediaPIB / nr_pib_nenul;
            mediaPOP = mediaPOP / nr_pop_nenul;
            mediaSV = mediaSV / nr_sv_nenul;
            //console.log(mediaSV);
            console.log(mediaPOP);
            //console.log(mediaPIB);
            //initialize min din viecare indicator cu primele valori din tabel
            minPIB = document.getElementById("tableBody").getElementsByTagName("tr")[0].getElementsByTagName("td")[1].textContent;
            minSV = document.getElementById("tableBody").getElementsByTagName("tr")[0].getElementsByTagName("td")[2].textContent;
            minPOP = document.getElementById("tableBody").getElementsByTagName("tr")[0].getElementsByTagName("td")[3].textContent;
            //parcurg tabelul si aflu minimul si maximul din tabel
            let mytableBody = document.getElementById("tableBody");
            for (let i = 0; i < nr_tari_distincte; i++) {

                let myrow = mytableBody.getElementsByTagName("tr")[i];
                let mycelPIB = myrow.getElementsByTagName("td")[1];
                let mycelSV = myrow.getElementsByTagName("td")[2];
                let mycelPOP = myrow.getElementsByTagName("td")[3];

                let valoarePIB = parseFloat(mycelPIB.textContent);
                let valoareSV = parseFloat(mycelSV.textContent);
                let valoarePOP = parseInt(mycelPOP.textContent);

                if (minPOP > valoarePOP && mycelPOP.textContent.length !== 0)
                    minPOP = valoarePOP;
                if (minPIB > valoarePIB && mycelPIB.textContent.length !== 0)
                    minPIB = valoarePIB;
                if (minSV > valoareSV && mycelSV.textContent.length !== 0) { minSV = valoareSV; }
                if (maxPIB < valoarePIB && mycelPIB.textContent.length !== 0)
                    maxPIB = valoarePIB;
                if (maxSV < valoareSV && mycelSV.textContent.length !== 0) {
                    maxSV = valoareSV;
                }
                if (maxPOP < valoarePOP && mycelPOP.textContent.length !== 0)
                    maxPOP = valoarePOP;
                //console.log(mycelSV.textContent);



                //console.log(mycelSV.textContent);



            }


            // console.log(minPIB);
            // console.log(maxPIB);
            // console.log(minSV);
            // console.log(maxSV);
            // console.log(minPOP);
            // console.log(maxPOP);
            //calculez diferenta maxima dintre medie si cel mai indepartat element ca caloare
            const difmaxPIB = Math.max((maxPIB - mediaPIB), (mediaPIB - minPIB));
            const difmaxSV = Math.max((maxSV - mediaSV), (mediaSV - minSV));
            const difmaxPOP = Math.max((maxPOP - mediaPOP), (mediaPIB - minPOP));

            // console.log(difmaxPIB);
            // console.log(difmaxSV);
            // console.log(difmaxPOP);
            //parcurg din nou tabelul si calculez diferenta dintre fiecare valoare si medie, daca valoarea este nula diferenat este 0
            for (let i = 0; i < nr_tari_distincte; i++) {

                let myrow = mytableBody.getElementsByTagName("tr")[i];
                let mycelPIB = myrow.getElementsByTagName("td")[1];
                let mycelSV = myrow.getElementsByTagName("td")[2];
                let mycelPOP = myrow.getElementsByTagName("td")[3];
                let valoarePIB = parseFloat(mycelPIB.textContent);
                let valoareSV = parseFloat(mycelSV.textContent);
                let valoarePOP = parseInt(mycelPOP.textContent);

                let difPIB = 0;
                let difSV = 0;
                let difPOP = 0
                if (mycelPIB.textContent.length === 0)
                    difPIB = 0;
                else
                    difPIB = Math.abs(mediaPIB - valoarePIB);
                if (mycelSV.textContent.length === 0)
                    difSV = 0;
                else
                    difSV = Math.abs(mediaSV - valoareSV);
                if (mycelPOP.textContent.length === 0)
                    difPOP = 0;
                else
                    difPOP = Math.abs(mediaPOP - valoarePOP);
                //calculez cat reprezinta fiecare diferenta din diferenta maxima
                let procentPIB = difPIB / difmaxPIB;
                let procentSV = difSV / difmaxSV;
                let procentPOP = difPOP / difmaxPOP;





                // let vPIB=(procentPIB*255);
                // let vSV=(procentSV*255);
                // let vPOP=(procentPOP*255);

                //colorez in functie de procentul calculat (cat la suta reprezinta diferenta dintre valoare si medie din diferenta maxima)
                //120-valoarea unghiului celui mai intens verde
                //cu cat procentul de diferenta creste cu atat culoarea se va orienta spre rosu(dif. maxima=> unghi 0 grade)
                //valoarea cu diferenta maxima va fi colorata cu rosu
                mycelSV.style.backgroundColor = "hsl(" + ((1 - procentSV) * 120) + ",100%,50%)";
                mycelPIB.style.backgroundColor = "hsl(" + ((1 - procentPIB) * 120) + ",100%,50%)";
                mycelPOP.style.backgroundColor = "hsl(" + ((1 - procentPOP) * 120) + ",100%,50%)";





                // mycelPIB.style.background="rgb("+vPIB+","+(255-vPIB)+","+0+")";
                // mycelSV.style.backgroundColor="rgb("+vSV+","+(255-vSV)+","+0+")";
                // mycelPOP.style.backgroundColor="rgb("+vPOP+","+(255-vPOP)+","+0+")";



            }




        })





})
//constuirea unei histrograme svg pe baza valorilor unui indicator pe ani
class BarChart {
    #domElement;
    #svgns;
    #svg;
    #width;
    #height;
    #title;
    /**
     * Constructs a new BarChart instance
     * @param {HTMLElement} domElement 
     */
    constructor(domElement, title) {
        this.#domElement = domElement;
        this.#title = title;
        this.#svgns = "http://www.w3.org/2000/svg"

    }
    /**
     * Display the bar chart
     * @param {Array} data 
     */
    draw(data) {
        this.#width = this.#domElement.clientWidth;
        this.#height = this.#domElement.clientHeight;
        this.#createSVG();
        this.#drawBackground();
        this.#drawBars(data);
        this.#drawTitle();

    }
    //constuirea svg-ului
    #createSVG() {
        //curatarea div-ului
        while (this.#domElement.firstChild)
            this.#domElement.removeChild(this.#domElement.firstChild)
        this.#svg = document.createElementNS(this.#svgns, "svg");
        this.#svg.setAttribute("width", this.#width);
        this.#svg.setAttribute("height", this.#height);
        this.#domElement.appendChild(this.#svg);

    }
    //constuirea dreptunghiului in care voi incadra graficul
    #drawBackground() {

        const rect = document.createElementNS(this.#svgns, "rect");
        rect.setAttribute("x", 0);
        rect.setAttribute("y", 0);
        //il constuiesc mai mic decat svg-ul pentru a-l putea depasi cu textul informativ
        rect.setAttribute("width", (this.#width - 250));
        rect.setAttribute("height", this.#height);
        rect.style.fill = "WhiteSmoke";
        rect.classList.add("rect");
        this.#svg.appendChild(rect);

    }
    //scrierea titlului
    #drawTitle() {
        const text = document.createElementNS(this.#svgns, "text");

        text.appendChild(document.createTextNode(this.#title));
        text.setAttribute("x", 10);
        text.setAttribute("y", 20);

        this.#svg.appendChild(text);

    }
    //desenarea barelor
    #drawBars(data) {
        //console.log(data)
        const barWidth = (this.#width - 250) / data.length;
        //console.log(data);
        const values = data.map(x => x[1]);
        const maxValue = Math.max(...values)
        //console.log(maxValue);
        const f = (this.#height) / maxValue;
        for (let i = 0; i < data.length; i++) {

            const label = data[i][0];
            const value = data[i][1];
            const barHeight = value * f * 0.9;
            const barX = i * barWidth;
            const barY = this.#height - barHeight;

            const bar = document.createElementNS(this.#svgns, "rect");

            bar.setAttribute("x", barX + barWidth / 4);
            bar.setAttribute("y", barY);
            bar.setAttribute("width", barWidth / 2);
            bar.setAttribute("height", barHeight);
            bar.classList.add("bar");
            this.#svg.classList.add("svg")
            bar.addEventListener("mouseover", () => {


                //desenarea tooltip-ului la trecerea cu mouse-ului pe o bara a graficului
                const text = document.createElementNS(this.#svgns, "text");
                const rect = document.createElementNS(this.#svgns, "rect");

                text.appendChild(document.createTextNode(label + ", valoarea: " + value));
                text.setAttribute("x", barX);
                text.setAttribute("y", barY);

                rect.setAttribute("x", barX);
                rect.setAttribute("y", barY - 20);
                rect.setAttribute("width", 200);
                rect.setAttribute("height", 25);
                rect.setAttribute("fill", "white");
                rect.appendChild(document.createTextNode("text"));
                text.color = "red";
                rect.classList.add("rectTool");
                //    const text=document.createElementNS(this.#svgns,"title");
                //    text.textContent="text";
                //    text.style.fill="black";


                text.classList.add("textSVG")

                // 
                rect.appendChild(text);

                this.#svg.appendChild(rect);
                this.#svg.appendChild(text);


            });
            //stergerea tooltipului dupa parasirea mouse-ului barei
            bar.addEventListener("mouseleave", () => {

                this.#svg.removeChild(this.#svg.lastChild);
                this.#svg.removeChild(this.#svg.lastChild);

            })
            this.#svg.appendChild(bar);
        }



    }

}
const btnDeseneaza = document.getElementById("btnDeseneaza");//butonul care la apasarea caruia se deseneaza graficul
const chart_div = document.getElementById("chart_div");//divul in care se va desena graficul
//s-a apasat pe buton
btnDeseneaza.addEventListener("click", function () {
    document.getElementById("chart_div").style.display = "block";
    //verific ce indicator si ce tara s-a ales
    const indicatorAles = document.getElementById("indicatorAles");
    const indicator = indicatorAles.options[indicatorAles.selectedIndex].innerHTML;

    const taraAleasa = document.getElementById("taraAleasa");
    const tara = taraAleasa.options[taraAleasa.selectedIndex].innerHTML;


    //console.log(tara);
    //citesc din json
    fetch("./media/eurostat.json")
        .then(response => response.json())
        .then((date) => {
            const vector = date;
            let data = []
            //console.log(vector);
            for (let i = 0; i < vector.length; i++) {
                //construiesc un vector cu valorile pentru tara si indicatorul dorit-vectorul va contine anul si valoarea indicatorului din anul respectiv
                if (vector[i].indicator === indicator && vector[i].tara === tara) {

                    let dataUnica = []
                    //asigurare existenta valoare
                    if (vector[i].valoare !== null) {
                        dataUnica.push("Anul: " + vector[i].an);
                        dataUnica.push(parseFloat(vector[i].valoare));
                        //console.log(dataUnica);
                        data.push(dataUnica);
                    }
                }
            }
            //console.log(data);
            //construiesc graficul
            const barChart = new BarChart(chart_div, ("Evolutia " + indicator + " in " + tara));
            barChart.draw(data);
        })



})
// constuire bubble chart grafia vectoriala
class BubbleChart {
    constructor(canvas) {
        this.canvas = canvas;
    }

    draw(data, anPrimit) {

        //diferentiere label-uri de valori 
        let valuesPIB = []
        let valuesPOP = []
        let valuesSV = []
        let tari = []
        let k = 0;

        for (let i = 0; i < data.length; i++) {
            if (data[i].pib !== null && data[i].pop !== null && data[i].sv !== null) {
                valuesPIB[k] = parseFloat(data[i].pib)
                valuesPOP[k] = parseInt(data[i].pop)
                valuesSV[k] = parseFloat(data[i].sv)
                tari[k] = data[i].tara
                k++;
            }
        }

        const context = this.canvas.getContext("2d")

        context.fillStyle = "#DEDEDE";
        //desenare cadrul in forma de dreptunghi in care se va realiza bubble chart-ul

        context.fillRect(0, 0, this.canvas.width, this.canvas.height);

        //calculare maxim pentru cei 3 indicatori
        let maxValueSV = 0;
        let maxValuePIB = 0;
        let maxValuePOP = 0;

        for (let i = 0; i < valuesSV.length; i++)
            if (maxValueSV < valuesSV[i])
                maxValueSV = valuesSV[i]

        for (let i = 0; i < valuesPIB.length; i++)
            if (maxValuePIB < valuesPIB[i])
                maxValuePIB = valuesPIB[i]

        for (let i = 0; i < valuesPOP.length; i++)
            if (maxValuePOP < valuesPOP[i])
                maxValuePOP = valuesPOP[i]

        //calculare unitate latime
        const barWidth = (this.canvas.width - 50) / maxValuePIB;
        //estimare o raza maxima
        let razaOrient = 50;
        //calculare unitate inaltime
        const f = this.canvas.height / maxValueSV;


        context.lineWidth = 2;



        for (let i = 0; i < tari.length; i++) {
            const barHeight = valuesSV[i] * f * 0.5;
            //calculez raza fiecarui cerc in functie de valoarea maxima  a POP si raza maxima
            let raza = (valuesPOP[i] / maxValuePOP) * razaOrient;
            //calculare X si Y
            const barX = valuesPIB[i] * barWidth;

            const barY = this.canvas.height - barHeight;


            //am desenat cercurile si le-am colorat cu albastru, transparenta culorii fiind in functie de marimea populatiei
            context.beginPath();
            let procent = valuesPOP[i] / maxValuePOP
            context.fillStyle = "rgba(0,0,255," + (1 - procent) + ")"
            context.arc(barX, barY, raza, 0, Math.PI * 2);
            context.fill();
            context.closePath();








        }

        //punere denumirea tarilor pe bule
        for (let i = 0; i < tari.length; i++) {
            const barHeight = valuesSV[i] * f * 0.5;
            //calculez raza fiecarui cerc in functie de valoarea maxima si raza maxima

            //console.log(razaOrient)
            const barX = valuesPIB[i] * barWidth;
            //am vrut sa construiesc bulele cele mai mari cel mai sus
            const barY = this.canvas.height - barHeight;
            context.beginPath();
            context.font = "20px";
            context.strokeStyle = "black"
            context.fillStyle = "black";
            //am pus numele tarii pe fiecare cerc
            context.fillText(tari[i].toString(), barX - 2, barY);
            context.fill();
            context.closePath();
        }
        context.beginPath();
        context.font = "20px";
        context.strokeStyle = "black"
        context.fillStyle = "black";
        //am pus numele tarii pe fiecare cerc
        context.fillText("Anul: " + anPrimit + " OX: PIB, OY:SV, Raza in functie de POP", 0, 20);
        context.fill();
        context.closePath();
    }
}
const btnDraw = document.getElementById("btnDeseneaza1");// butonul care deseneaza bubble chart-ul

const canvasChart = document.getElementById("canvasChart");// canvasul in care se deseneaza
//s-a apasat pe buton
btnDraw.addEventListener("click", () => {
    document.getElementById("canvasChart").style.display = "block";
    //verificare an ales




    const anAleas = document.getElementById("anAles1");
    const an = anAles1.options[anAleas.selectedIndex].innerHTML;

    fetch("./media/eurostat.json")
        .then(response => response.json())
        .then((date) => {
            const vector = date;


            const tari = [];
            for (let i = 0; i < vector.length; i++) {

                tari.push(vector[i].tara)

            }

            //construire vector cu tari distincte
            let nr_tari_distincte = 0;
            const tari_distincte = []
            let date_tari = []
            for (let i = 0; i < tari.length; i++) {
                if (nr_tari_distincte === 0) {
                    tari_distincte.push(tari[i]);
                    nr_tari_distincte++;
                }
                else {
                    let ok = 1;
                    for (let j = 0; j < nr_tari_distincte; j++) {
                        if (tari_distincte[j] === tari[i]) {
                            ok = 0;
                        }
                    }
                    if (ok === 1) {
                        tari_distincte.push(tari[i]);
                        nr_tari_distincte++;
                    }
                }

            }
            for (let j = 0; j < tari_distincte.length; j++) {

                const data = {
                    tara: tari_distincte[j],
                    pib: "-",
                    sv: "-",
                    pop: "-"

                };
                for (let i = 0; i < vector.length; i++) {

                    if (vector[i].an === an && vector[i].tara === tari_distincte[j]) {
                        if (vector[i].indicator === 'PIB') {
                            data.pib = vector[i].valoare;





                        }
                        if (vector[i].indicator === 'SV') {
                            data.sv = vector[i].valoare;


                        }
                        if (vector[i].indicator === 'POP') {
                            data.pop = vector[i].valoare;


                        }

                    }

                }
                //vector cu date pe un an pentru fiecare tara
                date_tari.push(data);


            }
            //desenare bubble chart
            const bubbleChart = new BubbleChart(canvasChart);
            bubbleChart.draw(date_tari, an);





        })


    //ajustarea dimensiunilor canvasului
    function reseizeCanvas() {
        canvasChart.width = canvasChart.clientWidth;
        canvasChart.height = canvasChart.clientHeight;
    }
    reseizeCanvas();
    //window.addEventListener("resize", () => reseizeCanvas());

});
//animatie bubble chart
//pentru fiecare an se construieste bubble chart-ul odata la o secunda
function evolutie(ok) {
    const canvasChart = document.getElementById("canvasChart");
    //incep cu anul 2000
    let an = 1999;
    var id = setInterval(evolueaza, 1000);
    function evolueaza() {
        if (an === 2018) {
            clearInterval(id);
        } else {

            an++;
            fetch("./media/eurostat.json")
                .then(response => response.json())
                .then((date) => {
                    const vector = date;


                    const tari = [];
                    for (let i = 0; i < vector.length; i++) {

                        tari.push(vector[i].tara)

                    }

                    let nr_tari_distincte = 0;
                    const tari_distincte = []
                    let date_tari = []
                    for (let i = 0; i < tari.length; i++) {
                        if (nr_tari_distincte === 0) {
                            tari_distincte.push(tari[i]);
                            nr_tari_distincte++;
                        }
                        else {
                            let ok = 1;
                            for (let j = 0; j < nr_tari_distincte; j++) {
                                if (tari_distincte[j] === tari[i]) {
                                    ok = 0;
                                }
                            }
                            if (ok === 1) {
                                tari_distincte.push(tari[i]);
                                nr_tari_distincte++;
                            }
                        }

                    }
                    for (let j = 0; j < tari_distincte.length; j++) {

                        const data = {
                            tara: tari_distincte[j],
                            pib: "-",
                            sv: "-",
                            pop: "-"

                        };
                        for (let i = 0; i < vector.length; i++) {


                            if (vector[i].an === an.toString() && vector[i].tara === tari_distincte[j]) {


                                if (vector[i].indicator === 'PIB') {
                                    data.pib = vector[i].valoare;





                                }
                                if (vector[i].indicator === 'SV') {
                                    data.sv = vector[i].valoare;


                                }
                                if (vector[i].indicator === 'POP') {
                                    data.pop = vector[i].valoare;


                                }

                            }

                        }
                        date_tari.push(data);

                    }

                    const bubbleChart = new BubbleChart(canvasChart);
                    bubbleChart.draw(date_tari, an);


                })
            if (ok === 0) {
                function reseizeCanvas() {
                    canvasChart.width = canvasChart.clientWidth;
                    canvasChart.height = canvasChart.clientHeight;
                    ok = 1;
                }
                reseizeCanvas();
               // window.addEventListener("resize", () => reseizeCanvas);
            }


        }
    }

}
//butonul care la apasarea caruia se realizeaza animatia
document.getElementById("btnDeseneaza2").addEventListener("click", () => {
    let ok = 1;
    if (document.getElementById("canvasChart").style.display === "none") {
        document.getElementById("canvasChart").style.display = "block";
        ok = 0;
    }
    evolutie(ok);

});
///varianta 2

class BubbleChart1 {
    constructor(canvas) {
        this.canvas = canvas;
    }

    draw(data, titlu) {
        //diferentiere label-uri de valori si calculare medie
        let values = []
        let tari = []
        for (let i = 0; i < data.length; i++) {
            values[i] = parseInt(data[i][1])
            tari[i] = data[i][0]
        }
        let medie = 0;
        for (let i = 0; i < data.length; i++)
            medie += values[i];
        medie = medie / values.length;



        //console.log(values)

        const context = this.canvas.getContext("2d")

        context.fillStyle = "#DEDEDE";

        context.fillRect(0, 0, this.canvas.width, this.canvas.height);

        //barWidth reprezinta valoarea maxima a diamterului unui cerc astfel incat daca valorile sunt egale cercurile sa nu se suprapuna
        const barWidth = this.canvas.width / values.length;
        //calculez raza maxima
        let razaOrient = barWidth / 2;
        //console.log(barWidth)

        //calcularea valorii maxime
        let maxValue = 0;
        for (let i = 0; i < values.length; i++)
            if (maxValue < values[i])
                maxValue = values[i]
        //console.log(maxValue)
        //calcularea inaltimii unei unitati
        const f = this.canvas.height / maxValue;//30


        context.lineWidth = 2;
        //console.log(values.length);

        for (let i = 0; i < values.length; i++) {
            const barHeight = values[i] * f * 0.9;
            //calculez raza fiecarui cerc in functie de valoarea maxima si raza maxima
            let raza = (values[i] / maxValue) * razaOrient;
            //console.log(razaOrient)
            const barX = i * barWidth + raza
            //am vrut sa construiesc bulele cele mai mari cel mai sus
            const barY = this.canvas.height - barHeight + raza;
            //context.arc(50, 50, 50, 0, Math.PI * 2, false);
            //console.log(barY)

            //am desenat cercurile si le-am colorat cu verde daca valorile lor erau peste medie si cu rosu in caz contrar
            context.beginPath();
            if (values[i] < medie)
                context.fillStyle = "red";
            else
                context.fillStyle = "green"
            context.arc(barX, barY, raza, 0, Math.PI * 2);
            context.fill();
            context.closePath();
            context.beginPath();
            context.font = "20px";
            context.strokeStyle = "black"
            context.fillStyle = "black";
            //am pus numele tarii pe fiecare cerc
            context.fillText(tari[i], barX - 2, barY);
            context.fill();
            context.closePath();


            context.fill()


        }
        context.beginPath();
        context.font = "20px";
        context.strokeStyle = "black"
        context.fillStyle = "black";
        //am pus numele tarii pe fiecare cerc
        context.fillText(titlu, 0, 20);
        context.fill();
        context.closePath();
    }
}
const btnDraw1 = document.getElementById("btnDeseneaza3");// butonul care deseneaza bubble chart-ul

const canvasChart1 = document.getElementById("canvasChart1");// canvasul in care se deseneaza
//s-a apasat pe buton
btnDraw1.addEventListener("click", () => {
    document.getElementById("canvasChart1").style.display = "block";
    //verificare indicator si an ales
    const indicatorAles = document.getElementById("indicatorAles1");
    const indicator = indicatorAles1.options[indicatorAles.selectedIndex].innerHTML;


    //console.log(indicator)
    const anAleas = document.getElementById("anAles2");
    const an = anAles.options[anAleas.selectedIndex].innerHTML;
    //console.log(an)
    //citire fisier
    fetch("./media/eurostat.json")
        .then(response => response.json())
        .then((date) => {
            const vector = date;
            let data = []
            //console.log(vector);
            //construire vector pentru indicatorul si anul ales. vectorul contine pentru fiecare tara numele acesteia si valoarea indicatorului
            for (let i = 0; i < vector.length; i++) {
                if (vector[i].indicator === indicator && vector[i].an.toString() === an) {

                    let dataUnica = []
                    //asigurare existenta valoare
                    if (vector[i].valoare != null) {
                        dataUnica.push(vector[i].tara);
                        dataUnica.push(parseFloat(vector[i].valoare));
                        //console.log(dataUnica);
                        data.push(dataUnica);
                    }
                }
            }
            //console.log(data);
            //desenare bubble chart
            const bubbleChart = new BubbleChart1(canvasChart1);
            const titlu = ("Indicatorul " + indicator + " in anul " + an)
            bubbleChart.draw(data, titlu);
        })


    //ajustarea dimensiunilor canvasului
    function reseizeCanvas1() {
        canvasChart1.width = canvasChart1.clientWidth;
        canvasChart1.height = canvasChart1.clientHeight;
    }
    reseizeCanvas1();
    //window.addEventListener("resize", () => reseizeCanvas1);

});
//animatie bubble chart
//pentru fiecare an se construieste bubble chart-ul odata la o secunda
function evolutie1(ok) {
    const canvasChart = document.getElementById("canvasChart1");
    const indicatorAles = document.getElementById("indicatorAles1");
    const indicator = indicatorAles1.options[indicatorAles.selectedIndex].innerHTML;
    let an = 1999;
    var id = setInterval(evolueaza, 1000);
    function evolueaza() {
        if (an === 2018) {
            clearInterval(id);
        } else {
            console.log(an);
            an++;
            fetch("./media/eurostat.json")
                .then(response => response.json())
                .then((date) => {
                    const vector = date;
                    let data = []
                    //console.log(vector);
                    for (let i = 0; i < vector.length; i++) {
                        if (vector[i].indicator === indicator && vector[i].an.toString() === an.toString()) {

                            let dataUnica = []
                            if (vector[i].valoare != null) {
                                dataUnica.push(vector[i].tara);
                                dataUnica.push(parseFloat(vector[i].valoare));
                                //console.log(dataUnica);
                                data.push(dataUnica);
                            }
                        }
                    }
                    //console.log(data);
                    const bubbleChart = new BubbleChart1(canvasChart1);
                    const titlu = ("Indicatorul " + indicator + " in anul " + an)
                    bubbleChart.draw(data, titlu);


                })
            if (ok === 0) 
            {
                function reseizeCanvas1() {
                    canvasChart1.width = canvasChart1.clientWidth;
                    canvasChart1.height = canvasChart1.clientHeight;
                    ok = 1;
                }
                reseizeCanvas1();
                //window.addEventListener("resize", () => reseizeCanvas1);
            }


        }
    }

}
//butonul care la apasarea caruia se realizeaza animatia
document.getElementById("btnDeseneaza4").addEventListener("click", () => {
    let ok = 1;
    if (document.getElementById("canvasChart1").style.display === "none") {
        document.getElementById("canvasChart1").style.display = "block";
        ok = 0;
    }
    evolutie1(ok);

});
