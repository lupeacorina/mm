"use strict";


const app = {
    btnPlayPause,
    audio,
    currentTime,
    duration,
    btnMuteUnMute,
    tracks: [],
    slider,
    sliderVolume,
    url : null
    
}


app.play = function(url,k){
    
    const tracks = document.querySelectorAll("li");
    for(let i=0; i < tracks.length; i++){
        tracks[i].classList.remove("active");
    }
    const currentTrack = tracks[k];
    currentTrack.classList.add("active");

    app.audio.src = app.url = url;
    app.audio.play();
    app.sliderVolume = document.getElementById("sliderVolume");
    app.audio.volume=app.sliderVolume.value/100;
}
app.playInitial = function(url,k,time,volume){
    
    const tracks = document.querySelectorAll("li");
    for(let i=0; i < tracks.length; i++){
        tracks[i].classList.remove("active");
    }
    const currentTrack = tracks[k];
    currentTrack.classList.add("active");

    app.audio.src = app.url = url;
    app.currentTime=time;
    app.sliderVolume=volume;
    // app.audio.volume=volume/100;
    
    console.log(app.currentTime);

    //app.play(url,k);  
    //app.audio.play();
    app.sliderVolume = document.getElementById("sliderVolume");
    app.audio.volume=app.sliderVolume.value/100;
}


app.load = function(){
    
fetch("./media/audio.json")
.then(response => response.json())
.then((data)=>{
let melodii;
melodii=data;

//console.log(melodii["album"]);
let cantece=[];
for(let i=0;i<melodii.length;i++)
{
    let cantec=[];
    cantec[0]=melodii[i]["name"]+"-"+melodii[i]["artist"];
    cantec[1]=melodii[i]["url"];
    cantec[2]=melodii[i]["cover_art_url"];
cantece[i]=cantec;
}
function chagePhoto(i){
    const img=document.createElement("img");
    img.src=cantece[i][2];
    if(img.src===""){
        img.src="./media/abum-art/music.jpg"
    }
    img.addEventListener("load", function(){  
    
    
    const canvas1=document.getElementById("canvas1");
    const ctx = canvas1.getContext("2d");


        
           const dWidth = 150;
           const dHeight = dWidth * img.naturalHeight / img.naturalWidth;                
           ctx.drawImage(img, ((canvas1.width/2)-(dWidth/2)), 0, dWidth, dHeight);
    })
}
//console.log(cantece);
const lista=document.getElementById("lista")
for(let i=0;i<cantece.length;i++)
{
    let item = document.createElement("li" );
    item.classList.add("list-group-item")
    
    item.appendChild(document.createTextNode(cantece[i][0]));
    
    lista.appendChild(item); 
}

    app.btnPlayPause = document.getElementById("btnPlayPause");
    app.audio = document.getElementById("audio");
    app.currentTime = document.getElementById("currentTime");
    app.duration = document.getElementById("duration");
    app.btnMuteUnMute = document.getElementById("btnMuteUnMute");
    app.slider = document.getElementById("slider");
    app.sliderVolume = document.getElementById("sliderVolume");

    const canvas = document.getElementById("canvas");
    

    app.slider.addEventListener("change", function(){
        app.audio.currentTime = app.slider.value;
    });
    app.sliderVolume.addEventListener("change", function(){
        //app.changeVolume(app.slider.value) ;
        app.audio.volume=app.sliderVolume.value/100;
        
    });

    document.getElementById("btnNext").addEventListener("click", ()=>{
        let index=0;
        for(let i=0;i<cantece.length;i++)
        {
            //console.log(app.url)
            if(cantece[i][1]===app.url)
          
            index=i;
        }
        index++;
       //console.log(index)
        if (index >= cantece.length)
            index = 0;
            app.slider.value=0
            chagePhoto(index);
        app.play(cantece[index][1],index);
    });

    const tracks = document.querySelectorAll("li");
    //const tracks=cantece;
    console.log(tracks[0])
    for(let i = 0; i < tracks.length; i++){
        const track = tracks[i];
        const url = cantece[i][1];
        app.tracks.push(url);

        track.addEventListener("click", ()=>{
            
            chagePhoto(i);
            app.slider.value=0
            app.play(url,i);
        });
    }

    app.btnMuteUnMute.addEventListener("click", function(){
        app.audio.muted = !app.audio.muted;
    })

    app.btnPlayPause.addEventListener("click", function(){
        if(app.audio.src === ""){
            app.play(app.tracks[0])
        } else {  
            if (app.audio.paused){
                app.audio.play();
            } else {
                app.audio.pause();
            }
        }
    });

    app.audio.addEventListener("play", function(){
        //app.btnPlayPause.innerText = "Pause";
        const i = app.btnPlayPause.children[0];
        i.classList.remove("fa-play");
        i.classList.add("fa-pause");

        
    });

    app.audio.addEventListener("pause", function(){
        //app.btnPlayPause.innerText = "Play";
        const i = app.btnPlayPause.children[0];
        i.classList.remove("fa-pause");
        i.classList.add("fa-play");
    });

    app.audio.addEventListener("durationchange", function(){
        app.duration.innerText = app.secondsToString(app.audio.duration);

        app.slider.max = app.audio.duration;
    });

    app.audio.addEventListener("timeupdate", function(){
        const currentTime = document.getElementById("currentTime");

        if (app.audio.duration) {
            currentTime.textContent = app.secondsToString(app.audio.currentTime);
        }
        else {
            //innerText can also be used
            //differences https://www.w3schools.com/jsref/prop_html_innerhtml.asp
            currentTime.textContent = '...';
        };
    });

    app.audio.addEventListener("ended", function(){
        //let index = app.tracks.indexOf(app.audio.src);
        let index=0;
        for(let i=0;i<cantece.length;i++)
        {
            //console.log(app.url)
            if(cantece[i][1]===app.url)
          
            index=i;
        }
        index++;
       //console.log(index)
        if (index >= cantece.length)
            index = 0;
            chagePhoto(index);
            app.slider.value=0
        app.play(cantece[index][1],index);
    });
});

}

app.secondsToString = function(seconds){
    const min = Math.floor(seconds / 60);
    const sec = Math.floor(seconds % 60);

    const secAsString = sec >= 10 ? sec : "0"+sec;

    return min + ":"+secAsString;
}
window.addEventListener("beforeunload", function (e) {
    localStorage.currentTime=app.audio.currentTime;  
    localStorage.sliderVolume=app.sliderVolume;
    localStorage.url=app.url;
    localStorage.slider=app.slider;
    console.log(localStorage.currentTime);
  
});
window.addEventListener('load', (event) => {
    console.log(localStorage.url);
    if (typeof(Storage) !== "undefined") {
        
        if (localStorage.currentTime) {
            
          
          app.audio.currentTime=localStorage.currentTime;
          app.url=localStorage.url;
          app.sliderVolume.value=localStorage.sliderVolume;
          app.slider.value=app.audio.currentTime;
         
     
        } 
        else{
            localStorage.url="./media/songs/Delia - Arunca-ma _ Official Video (320 kbps).mp3";
            localStorage.currentTime=0;
            localStorage.sliderVolume=0;
            localStorage.slider=0;
            app.audio.currentTime=0;
            app.url="./media/songs/Delia - Arunca-ma _ Official Video (320 kbps).mp3"
            app.sliderVolume=0.5;
            app.slider=0;
        }
         
       
        
      }
      else {
          
        app.audio.currentTime=0;
        app.url="./media/songs/Delia - Arunca-ma _ Official Video (320 kbps).mp3"
        app.sliderVolume=0.5;
        app.slider=0;

    }
    fetch("./media/audio.json")
    .then(response => response.json())
    .then((data)=>{
    let melodii;
    melodii=data;
    
    //console.log(melodii["album"]);
    let cantece=[];
    for(let i=0;i<melodii.length;i++)
    {
        let cantec=[];
        cantec[0]=melodii[i]["name"]+"-"+melodii[i]["artist"];
        cantec[1]=melodii[i]["url"];
        cantec[2]=melodii[i]["cover_art_url"];
    cantece[i]=cantec;
    }
    function chagePhoto(i){
        const img=document.createElement("img");
        img.src=cantece[i][2];
        if(img.src===""){
            img.src="./media/abum-art/music.jpg"
        }
        img.addEventListener("load", function(){  
        
        
        const canvas1=document.getElementById("canvas1");
        const ctx = canvas1.getContext("2d");
    
    
            
               const dWidth = 150;
               const dHeight = dWidth * img.naturalHeight / img.naturalWidth;                
               ctx.drawImage(img, ((canvas1.width/2)-(dWidth/2)), 0, dWidth, dHeight);
        })
    }
    let index=0;
        for(let i=0;i<cantece.length;i++)
        {
            //console.log(cantece[i][1])
            if(cantece[i][1]===localStorage.url)
          
            index=i;
        }
        // app.load();
        chagePhoto(index);
        //app.audio.play()
        // app.audio.muted=true;
        // app.audio.autoplay=true;
        //app.audio.currentTime=localStorage.currentTime;
        
       // btnPlayPause.click();
        app.playInitial(localStorage.url,index,localStorage.currentTime,localStorage.sliderVolume);
      
        console.log(localStorage.url,index,localStorage.currentTime,localStorage.sliderVolume)
        
})
    
});
 

